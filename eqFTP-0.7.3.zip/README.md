##eqFTP
FTP client for Brackets code editor.

**Project is currenlty frozen. New version will be out someday. No ETA**

Donate via **[PATREON](https://patreon.com/equals182)** and I will stream coding process lol

[![](https://raw.githubusercontent.com/Equals182/Equals182.github.io/master/patreon-medium-button.png)](https://patreon.com/equals182)

[![](https://raw.githubusercontent.com/Equals182/Equals182.github.io/master/eqFTP-card.png)](http://equals182.github.io/eqFTP/)
