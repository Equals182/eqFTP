##eqFTP
FTP client for Brackets code editor.

[![](http://api.flattr.com/button/flattr-badge-large.png)](http://flattr.com/thing/3912923/Equals182eqFTP-on-GitHub)  
*Donate with Flattr. Be awesome.*

**[Help with translations!](http://equals182.github.io/eqFTP/#how-can-i-help-this-project) A lot of translation updates needed**

[![](https://raw.githubusercontent.com/Equals182/Equals182.github.io/master/eqFTP-card.png)](http://equals182.github.io/eqFTP/)
